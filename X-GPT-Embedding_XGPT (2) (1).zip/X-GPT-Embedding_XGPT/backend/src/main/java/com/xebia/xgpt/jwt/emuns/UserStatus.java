package com.xebia.xgpt.jwt.emuns;

public enum UserStatus {
    ACTIVE,INACTIVE
}
