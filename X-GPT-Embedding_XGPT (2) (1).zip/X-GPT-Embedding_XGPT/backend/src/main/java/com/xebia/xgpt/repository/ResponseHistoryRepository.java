package com.xebia.xgpt.repository;

import com.xebia.xgpt.model.ResponseHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;

public interface ResponseHistoryRepository extends JpaRepository<ResponseHistory, Long> {

    @Transactional
    @Modifying
    @Query(value = "insert into response_history (userid, session_id, response, chat_session_id, country_code)" +
            " values (:userId, :sessionId, :response, :chatSessionId, :countryCode)"
            , nativeQuery = true)
    void saveResponses(@Param("userId") Long userId,
                       @Param("sessionId") String loginSessionId,
                       @Param("response") String response,
                       @Param("chatSessionId") String chatSessionId,
                       @Param("countryCode") String countryCode);

    @Query(value = "select * from response_history where userid = :userId and session_id= :sessionId and chat_session_id= :chatSessionId",
            nativeQuery = true)
    List<ResponseHistory> getResponseHistory(@Param("userId") Long userId,
                                             @Param("sessionId") String sessionId,
                                             @Param("chatSessionId") String chatSessionId);
}
