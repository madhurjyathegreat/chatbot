package com.xebia.xgpt.jwt.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenericResponseDTO {
    private Long id;
    private String email;
    private String firstName;
    private String lastName;
    private String status;

    public GenericResponseDTO(String status) {
        this.status = status;
    }
}
