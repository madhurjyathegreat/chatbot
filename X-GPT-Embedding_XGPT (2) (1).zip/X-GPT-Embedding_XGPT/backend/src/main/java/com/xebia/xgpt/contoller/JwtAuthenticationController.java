package com.xebia.xgpt.contoller;

import com.xebia.xgpt.jwt.JwtTokenRequest;
import com.xebia.xgpt.jwt.JwtTokenResponse;
import com.xebia.xgpt.jwt.JwtTokenUtil;
import com.xebia.xgpt.jwt.JwtUserDetails;
import com.xebia.xgpt.jwt.constants.ApplicationConstant;
import com.xebia.xgpt.jwt.dto.ResponseDTO;
import com.xebia.xgpt.jwt.emuns.UserStatus;
import com.xebia.xgpt.jwt.exception.AuthenticationException;
import com.xebia.xgpt.jwt.model.User;
import com.xebia.xgpt.jwt.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class JwtAuthenticationController {
    @Value("${jwt.http.request.header}")
    private String tokenHeader;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private final JwtTokenUtil jwtTokenUtil;
    @Autowired
    private final UserDetailsService jwtInMemoryUserDetailsService;
    @Autowired
    private final UserService userService;

    public JwtAuthenticationController(JwtTokenUtil jwtTokenUtil,
                                       UserDetailsService jwtInMemoryUserDetailsService,
                                       UserService userService) {
        this.jwtTokenUtil = jwtTokenUtil;
        this.jwtInMemoryUserDetailsService = jwtInMemoryUserDetailsService;
        this.userService = userService;
    }

    @PostMapping(value = "${jwt.get.token.uri}")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtTokenRequest authenticationRequest) throws AuthenticationException {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        final UserDetails userDetails = jwtInMemoryUserDetailsService.loadUserByUsername(authenticationRequest.getUserName());
        JwtUserDetails jwtUserDetails = (JwtUserDetails) userDetails;
        if (userDetails == null) {
            return ResponseEntity.badRequest().body(new ResponseDTO<>(ApplicationConstant.USER_NOT_EXIST));
        } else {
            UserStatus userStatus = userService.findStatusById(jwtUserDetails.getId());
            if (userStatus == UserStatus.INACTIVE) {
                return ResponseEntity.badRequest().body(new ResponseDTO<>(ApplicationConstant.ACCOUNT_NOT_ACTIVATED));
            } else {
                if (authenticationRequest.getPassword() == null || !(encoder.matches(authenticationRequest.getPassword(), jwtUserDetails.getPassword()))) {
                    return ResponseEntity.badRequest().body(new ResponseDTO<>(ApplicationConstant.INVALID_USER_CREDENTIALS));
                } else {
                    authenticate(authenticationRequest.getUserName(), authenticationRequest.getPassword());
                    final String token = jwtTokenUtil.generateToken(userDetails);
                    User user = userService.findUserByEmailId(userDetails.getUsername());
                    return ResponseEntity.ok(new JwtTokenResponse(token, user));
                }
            }
        }
    }

    private void authenticate(String username, String password) {
        Objects.requireNonNull(username);
        Objects.requireNonNull(password);
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (DisabledException ex) {
            throw new AuthenticationException("USER_DISABLED", ex);
        } catch (BadCredentialsException ex) {
            throw new AuthenticationException("INVALID_CREDENTIALS", ex);
        }
    }

    @ExceptionHandler({AuthenticationException.class})
    public ResponseEntity<String> handleAuthenticationException(AuthenticationException e) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
    }
}