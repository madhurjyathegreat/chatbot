package com.xebia.xgpt.jwt.service;

import com.xebia.xgpt.jwt.dto.GenericResponseDTO;
import com.xebia.xgpt.jwt.dto.ResponseDTO;
import com.xebia.xgpt.jwt.dto.XGptUsersDTO;
import com.xebia.xgpt.jwt.emuns.UserStatus;
import com.xebia.xgpt.jwt.model.User;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;


public interface UserService {

    User findUserByEmailId(String email);

    User save(User user);

    ResponseEntity<GenericResponseDTO> userLogin(User user, HttpServletRequest request);

    UserStatus findStatusById(Long id);

    User findById(Long id);

    ResponseDTO update(User user, int status);

    XGptUsersDTO findAllUsers(int pageNo, int pageSize, String sortBy);

    String forgotPassword(String email, String host);

    String resetPassword(String token, String password);
}
