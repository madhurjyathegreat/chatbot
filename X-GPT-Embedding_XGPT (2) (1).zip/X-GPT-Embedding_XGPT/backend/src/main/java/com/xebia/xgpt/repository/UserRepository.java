package com.xebia.xgpt.repository;

import com.xebia.xgpt.jwt.emuns.UserStatus;
import com.xebia.xgpt.jwt.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @Query(value = "select status from User where id=?1")
    UserStatus findStatusById(Long id);

    User findByToken(String token);

    @Query(
            value = "select u.id as id,u.first_name as firstName,u.last_name as lastName,u.email as email,u.status as status,r.name as role from user u inner join user_role r where u.role_id=r.id  and r.name!=?1 order by u.id",
            countQuery = "select count(*) from user u inner join user_role r where u.role_id=r.id  and r.name!=?1 order by u.id",
            nativeQuery = true
    )
    Page<UserEvent> findAllXgptUsers(String role, Pageable pageable);

    interface UserEvent {
        Long getId();

        String getFirstName();

        String getLastName();

        String getEmail();

        String getRole();

        UserStatus getStatus();
    }
}
