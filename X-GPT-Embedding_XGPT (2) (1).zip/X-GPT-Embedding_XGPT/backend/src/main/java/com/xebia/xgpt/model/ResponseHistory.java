package com.xebia.xgpt.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "response_history")
public class ResponseHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "userid")
    private Long userId;
    @Column(name = "session_id")
    private String sessionId;
    @Column(name = "response", columnDefinition = "longtext")
    private String response;
    @Column(name = "chat_session_id")
    private String chatSessionId;
    @Column(name = "country_code")
    private String countryCode;
}

