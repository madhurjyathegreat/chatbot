package com.xebia.xgpt.jwt.dto;

import lombok.Data;

@Data
public class ResponseDTO<T> {
    boolean status = true;
    String message = " ";
    T data;

    public void setSuccessResponse(T data, String msg) {
        this.status = true;
        this.data = data;
        this.message = msg != null ? msg : " ";
    }

    public void setFailureResponse(String msg, T data) {
        this.status = false;
        this.message = msg;
        this.data = data;
    }

    public void setErrorResponse(Exception ex, String msg) {
        this.status = false;
        this.message = msg;
        this.data = null;
        ex.printStackTrace();
    }


    public ResponseDTO(String msg) {
        this.status = false;
        this.message = msg;
        this.data = null;
    }

    public ResponseDTO() {
    }
}
