package com.xebia.xgpt.jwt;

import com.xebia.xgpt.jwt.model.User;
import com.xebia.xgpt.jwt.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
public class JwtInMemoryUserDetailsService implements UserDetailsService {
    @Autowired
    UserService userService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userService.findUserByEmailId(username);
        JwtUserDetails jwtUserDetails = null;
        if (user != null) {
            jwtUserDetails = new JwtUserDetails(user.getId(), user.getEmail(),
                    user.getPassword(), user.getRole());
        }
        return jwtUserDetails;
    }
}
