package com.xebia.xgpt.contoller;

import com.xebia.xgpt.jwt.dto.GenericResponseDTO;
import com.xebia.xgpt.jwt.model.User;
import com.xebia.xgpt.jwt.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class LoginController {
    @Autowired
    private final UserService userService;

    private static final String LOGOUT_SUCCESS = "Logout Successful.";

    public LoginController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/authenticateTheUser")
    public ResponseEntity<GenericResponseDTO> userLogin(@RequestBody User user,
                                                        HttpServletRequest request) {
        return userService.userLogin(user, request);
    }

    @PostMapping("/logout")
    public ResponseEntity<GenericResponseDTO> logout(HttpServletRequest request) {
        request.getSession().invalidate();
        return ResponseEntity.ok(new GenericResponseDTO(LOGOUT_SUCCESS));
    }

    @PostMapping(value = "/api/xgpt/v1/public/forgot-password")
    public String forgotPassword(@RequestParam String email, @RequestParam String host) {
        String response = userService.forgotPassword(email, host);
        if (response.startsWith("Invalid")) {
            return response;
        }
        return response + " Token Sent Successfully";
    }

    @PutMapping("/api/xgpt/v1/public/reset-password")
    public String resetPassword(@RequestParam String token,
                                @RequestParam String password) {
        return userService.resetPassword(token, password);
    }
}