package com.xebia.xgpt.contoller;

import com.xebia.xgpt.jwt.constants.ApplicationConstant;
import com.xebia.xgpt.jwt.dto.ResponseDTO;
import com.xebia.xgpt.jwt.dto.UserDTO;
import com.xebia.xgpt.jwt.emuns.UserStatus;
import com.xebia.xgpt.jwt.model.User;
import com.xebia.xgpt.jwt.service.RoleService;
import com.xebia.xgpt.jwt.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/xgpt/v1/")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class XGptUserController {
    @Autowired
    private final UserService userService;

    @Autowired
    private final RoleService roleService;

    public XGptUserController(UserService userService, RoleService roleService) {
        this.userService = userService;
        this.roleService = roleService;
    }

    @PostMapping("/public/register")
    public ResponseEntity<ResponseDTO> processRegistrationForm(@RequestBody UserDTO userDTO) {

        // check the database if user already exists
        User existing = userService.findUserByEmailId(userDTO.getEmail());
        ResponseDTO responseDTO = new ResponseDTO();

        if (existing != null) {
            responseDTO.setSuccessResponse(existing, ApplicationConstant.USER_EXISTS);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(responseDTO);
        }
        // create user account        						
        User user = userService.save(createNewUser(userDTO));
        responseDTO.setSuccessResponse(user, ApplicationConstant.REGISTRATION_SUCCESS);
        return ResponseEntity.ok().body(responseDTO);
    }

    @PreAuthorize("hasAnyAuthority('XgptAdmin')")
    @PutMapping("/user/{id}")
    public ResponseDTO<User> update(@PathVariable("id") Long id,
                                    @RequestParam(value = "status") Integer status) {
        ResponseDTO<User> responseDTO = new ResponseDTO<>();
        try {
            User user = userService.findById(id);
            if (user == null) {
                responseDTO.setFailureResponse(ApplicationConstant.USER_NOT_EXIST, null);
            } else {
                responseDTO = userService.update(user, status);
            }
        } catch (Exception ex) {
            responseDTO.setErrorResponse(ex, ApplicationConstant.ERROR_MESSAGE);
        }
        return responseDTO;
    }

    @PreAuthorize("hasAnyAuthority('XgptAdmin')")
    @GetMapping("/user/list")
    public ResponseDTO list(@RequestParam(defaultValue = "0") Integer pageNo,
                            @RequestParam(defaultValue = "10") Integer pageSize,
                            @RequestParam(defaultValue = "id") String sortBy) {
        ResponseDTO responseDTO = new ResponseDTO<>();
        try {
            responseDTO.setSuccessResponse(userService.findAllUsers(pageNo, pageSize, sortBy),
                    ApplicationConstant.OPERATION_SUCCESS);
        } catch (Exception ex) {
            responseDTO.setErrorResponse(ex, ApplicationConstant.ERROR_MESSAGE);
        }
        return responseDTO;
    }

    private User createNewUser(UserDTO userDTO) {
        User user = new User();
        user.setFirstName(userDTO.getFirstName());
        user.setLastName(userDTO.getLastName());
        user.setEmail(userDTO.getEmail());
        user.setStatus(UserStatus.ACTIVE);
        user.setPassword(new BCryptPasswordEncoder().encode(userDTO.getPassword()));
        user.setRole(roleService.findByName("User"));
        return user;
    }
}