package com.xebia.xgpt.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public record SuccessResponse(@JsonProperty("message") String message) {
}
