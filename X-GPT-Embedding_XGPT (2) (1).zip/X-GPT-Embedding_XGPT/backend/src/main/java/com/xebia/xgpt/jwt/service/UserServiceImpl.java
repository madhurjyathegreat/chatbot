package com.xebia.xgpt.jwt.service;

import com.xebia.xgpt.jwt.constants.ApplicationConstant;
import com.xebia.xgpt.jwt.dto.GenericResponseDTO;
import com.xebia.xgpt.jwt.dto.ResponseDTO;
import com.xebia.xgpt.jwt.dto.XGptUsersDTO;
import com.xebia.xgpt.jwt.emuns.UserStatus;
import com.xebia.xgpt.jwt.model.User;
import com.xebia.xgpt.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private final UserRepository userRepository;
    @Autowired
    private final MailService mailService;
    @Autowired
    private EntityManager entityManager;
    private static final String LOGIN_SUCCESS = "Login Success.";

    private static final String INVALID_PASSWORD = "Invalid Password.";

    private static final String INVALID_USER = "User not found.";

    private static final long EXPIRE_TOKEN_AFTER_MINUTES = 30;

    public UserServiceImpl(UserRepository userRepository, MailService mailService) {
        this.userRepository = userRepository;
        this.mailService = mailService;
    }

    @Override
    public User findUserByEmailId(String email) {
        Session currentSession = entityManager.unwrap(Session.class);
        Query<User> theQuery = currentSession.createQuery("from User where email=:uEmail", User.class);
        theQuery.setParameter("uEmail", email);
        User theUser;
        try {
            theUser = theQuery.getSingleResult();
        } catch (Exception e) {
            theUser = null;
        }

        return theUser;
    }

    @Override
    public ResponseEntity<GenericResponseDTO> userLogin(User user, HttpServletRequest request) {
        User fetchedUser = findUserByEmailId(user.getEmail());
        GenericResponseDTO loginResponse = new GenericResponseDTO();
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        if (fetchedUser != null) {
            if (encoder.matches(user.getPassword(), fetchedUser.getPassword())) {
                HttpSession session = request.getSession();
                loginResponse.setId(fetchedUser.getId());
                loginResponse.setFirstName(fetchedUser.getFirstName());
                loginResponse.setLastName(fetchedUser.getLastName());
                loginResponse.setEmail(fetchedUser.getEmail());
                loginResponse.setStatus(LOGIN_SUCCESS);
                session.setAttribute("user", loginResponse);
                return ResponseEntity.ok(loginResponse);
            } else {
                loginResponse.setStatus(INVALID_PASSWORD);
                loginResponse.setEmail(user.getEmail());
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginResponse);
            }
        } else {
            loginResponse.setStatus(INVALID_USER);
            loginResponse.setEmail(user.getEmail());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginResponse);
        }
    }

    @Override
    @Transactional
    public User save(User user) {
        return userRepository.save(user);
    }

    @Override
    public UserStatus findStatusById(Long id) {
        return userRepository.findStatusById(id);
    }

    @Override
    public User findById(Long id) {
        return userRepository.findById(id).get();
    }

    @Override
    public ResponseDTO update(User user, int status) {
        ResponseDTO<User> responseDTO = new ResponseDTO<>();
        if (status == 0)
            user.setStatus(UserStatus.INACTIVE);
        else
            user.setStatus(UserStatus.ACTIVE);
        responseDTO.setSuccessResponse(userRepository.save(user), ApplicationConstant.USER_ACCOUNT_UPDATED);
        return responseDTO;
    }

    @Override
    public XGptUsersDTO findAllUsers(int pageNo, int pageSize, String sortBy) {
        Pageable paging = PageRequest.of(pageNo, pageSize);
        Page<UserRepository.UserEvent> result = userRepository.findAllXgptUsers("XgptAdmin", paging);
        if (result.hasContent()) {
            return new XGptUsersDTO(result.getTotalElements(), result.getContent());
        } else {
            return new XGptUsersDTO(0L, result.getContent());
        }
    }

    private String generateToken() {
        return String.valueOf(UUID.randomUUID());
    }

    public String forgotPassword(String email, String host) {
        Optional<User> userOptional = Optional
                .ofNullable(findUserByEmailId(email));
        if (userOptional.isEmpty()) {
            return "Invalid email id.!!";
        }
        User user = userOptional.get();
        user.setToken(generateToken());
        user.setTokenCreationDate(LocalDateTime.now());
        user = save(user);
        mailService.sendEmail(host, email, user.getToken());
        return user.getToken();
    }

    public String resetPassword(String token, String password) {
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        Optional<User> userOptional = Optional
                .ofNullable(userRepository.findByToken(token));
        if (userOptional.isEmpty()) {
            return "Invalid token.";
        }
        LocalDateTime tokenCreationDate = userOptional.get().getTokenCreationDate();
        if (isTokenExpired(tokenCreationDate)) {
            return "Token expired.";
        }
        User user = userOptional.get();
        user.setPassword(bCryptPasswordEncoder.encode(password));
        user.setToken(null);
        user.setTokenCreationDate(null);
        userRepository.saveAndFlush(user);
        return "Your password successfully updated..!!";
    }

    private boolean isTokenExpired(final LocalDateTime tokenCreationDate) {
        LocalDateTime now = LocalDateTime.now();
        Duration diff = Duration.between(tokenCreationDate, now);
        return diff.toMinutes() >= EXPIRE_TOKEN_AFTER_MINUTES;
    }
}