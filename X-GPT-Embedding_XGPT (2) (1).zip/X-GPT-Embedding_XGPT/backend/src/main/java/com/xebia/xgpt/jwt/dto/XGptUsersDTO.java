package com.xebia.xgpt.jwt.dto;

import com.xebia.xgpt.repository.UserRepository;
import lombok.Data;

import java.util.List;

@Data
public class XGptUsersDTO {
    Long totalUsers;
    List<UserRepository.UserEvent> users;

    public XGptUsersDTO() {
    }

    public XGptUsersDTO(Long totalUsers, List<UserRepository.UserEvent> users) {
        this.totalUsers = totalUsers;
        this.users = users;
    }
}
