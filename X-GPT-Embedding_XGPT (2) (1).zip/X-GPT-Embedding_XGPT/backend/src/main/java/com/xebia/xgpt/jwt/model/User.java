package com.xebia.xgpt.jwt.model;

import com.xebia.xgpt.jwt.emuns.UserStatus;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "email")  //username is email
	private String email;

	@Column(name = "password")
	private String password;

	@OneToOne
	private Role role;

	@Column(name="status")
	private UserStatus status;

	private String token;

	private LocalDateTime tokenCreationDate;
}
