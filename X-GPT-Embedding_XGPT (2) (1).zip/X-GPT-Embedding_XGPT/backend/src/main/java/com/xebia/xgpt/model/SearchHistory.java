package com.xebia.xgpt.model;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Data
@Entity
@Table(name = "search_history")
public class SearchHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "userid")
    private Long userId;
    @Column(name = "session_id")
    private String sessionId;
    @Column(name = "recent_search")
    private String recentSearch;
    @Column(name = "search_time")
    private Timestamp searchTime;
    @Column(name = "chatuser", columnDefinition = "longtext")
    private String chatuser;
    @Column(name = "chat_session_id")
    private String chatSessionId;
}

