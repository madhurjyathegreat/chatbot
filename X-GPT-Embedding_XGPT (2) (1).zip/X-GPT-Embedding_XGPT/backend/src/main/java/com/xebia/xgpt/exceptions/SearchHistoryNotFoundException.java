package com.xebia.xgpt.exceptions;

public class SearchHistoryNotFoundException extends RuntimeException{
    final String code;
    public SearchHistoryNotFoundException(String message, String code) {
        super(message);
        this.code = code;
    }
}
