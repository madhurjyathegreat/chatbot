package com.xebia.xgpt;

import com.xebia.xgpt.jwt.service.BootstrapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.xebia.xgpt.repository")
public class XGptApplication {
    @Autowired
    BootstrapService bootstrapService;

    public static void main(String[] args) {
        SpringApplication.run(XGptApplication.class, args);
    }

    @EventListener
    void onStartup(ApplicationEvent applicationEvent) {
        bootstrapService.addRoles();
        bootstrapService.addXgptAdmin();
    }
}
