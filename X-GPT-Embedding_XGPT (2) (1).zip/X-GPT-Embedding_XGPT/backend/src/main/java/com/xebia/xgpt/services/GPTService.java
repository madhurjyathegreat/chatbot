package com.xebia.xgpt.services;

import com.xebia.xgpt.exceptions.DataNotFoundException;
import com.xebia.xgpt.exceptions.SearchHistoryNotFoundException;
import com.xebia.xgpt.model.ResponseHistory;
import com.xebia.xgpt.model.SearchHistory;
import com.xebia.xgpt.repository.ResponseHistoryRepository;
import com.xebia.xgpt.repository.SearchHistoryRepository;
import com.xebia.xgpt.response.SessionIdResponse;
import com.xebia.xgpt.response.SuccessResponse;
import com.xebia.xgpt.utility.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.*;
import java.util.*;

@Slf4j
@Service
public class GPTService {
    private final SearchHistoryRepository searchHistoryRepository;
    private final ResponseHistoryRepository responseHistoryRepository;

    public GPTService(SearchHistoryRepository searchHistoryRepository,
                      ResponseHistoryRepository responseHistoryRepository) {
        this.searchHistoryRepository = searchHistoryRepository;
        this.responseHistoryRepository = responseHistoryRepository;
    }

    public Map<String, String> getInfo(String prompt, String message, Long userId, String sessionId, String chatSessionId) {
        Map<String, String> map = new HashMap<>();
        List<String> resultList = new ArrayList<>();
        List<String> listOfCountries = List.of("UK", "United Kingdom", "Italy", "Spain", "Netherlands", "Austria", "France");
        ProcessBuilder pb;
        String line;
        String chatMessage;
        StringBuilder sb = new StringBuilder();
        String countryCode;
        try {
            List<ResponseHistory> responseHistory = responseHistoryRepository.getResponseHistory(userId, sessionId, chatSessionId);
            if (listOfCountries.stream().anyMatch(country -> message.toLowerCase().contains(country.toLowerCase()))) {
                responseHistory.clear();
                responseHistoryRepository.deleteAll();
            }
            if (responseHistory.isEmpty()) {
                chatMessage = Constants.EMPTY_STRING;
                countryCode = checkCountryCode(message);
            } else {
                responseHistory.forEach(history -> sb
                        .append(history.getResponse())
                        .append(" "));
                chatMessage = sb + " now the question is";
                countryCode = StringUtils.isBlank(responseHistory.get(0).getCountryCode()) ? Constants.EMPTY_STRING : responseHistory.get(0).getCountryCode();
            }

            log.info("clubbed message is : [{}], message is : [{}] and country code is : [{}]", chatMessage, message, countryCode);
            File regexFile = ResourceUtils.getFile("classpath:final test.py");
            pb = new ProcessBuilder("python", regexFile.getAbsolutePath(),
                    prompt,
                    chatMessage,
                    message,
                    countryCode
            ).redirectErrorStream(true);
            Process process = pb.start();
            BufferedReader bfr = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while ((line = bfr.readLine()) != null) {
                resultList.add(line);
            }
            process.waitFor();
            StringBuilder builder = new StringBuilder();
            if (!resultList.isEmpty()) {
                resultList.forEach(data -> log.info("list : {}", data));
                resultList.forEach(data ->
                {
                    if (StringUtils.isNotBlank(data)) {
                        builder.append(data).append("/n").append(" ");
                    }
                });
            } else {
                throw new DataNotFoundException("Data is empty", "DATA_NOT_FOUND");
            }
            builder.deleteCharAt(builder.length() - 1);
            String finalData = builder.toString();
            map.put("result", finalData);
            return map;
        } catch (IOException | InterruptedException e) {
            throw new DataNotFoundException("Error...While getting data", "DATA_NOT_FOUND");
        }
    }

    public List<String> getPromptInfo() {
        String[] cols;
        List<String> promptList = new ArrayList<>();
        try {
            File promptFile = ResourceUtils.getFile("classpath:prompts.csv");
            String line;
            String cvsSplitBy = Constants.COMMA;
            BufferedReader br = new BufferedReader(new FileReader(promptFile));
            while ((line = br.readLine()) != null) {
                cols = line.split(cvsSplitBy);
                promptList.add(cols[0].replace("\"", ""));
            }
            promptList.remove(0);
            Collections.sort(promptList);
            return promptList;
        } catch (IOException e) {
            throw new DataNotFoundException("Error...While getting data", "DATA_NOT_FOUND");
        }
    }

    public SuccessResponse addRecentSearch(Long id, String loginSessionId,
                                           String message, String answer,
                                           String chatSessionId) {
        String countryCode = checkCountryCode(message);

        var saveRecentSearch = searchHistoryRepository.saveRecentSearch(id, loginSessionId,
                message, answer, chatSessionId);
        responseHistoryRepository.saveResponses(id, loginSessionId, answer, chatSessionId, countryCode);
        if (saveRecentSearch == 1) {
            return new SuccessResponse("successfully save search history");
        } else {
            throw new SearchHistoryNotFoundException("Error.. history not saved", "HISTORY_NOT_SAVED");
        }
    }

    private String checkCountryCode(String message) {
        String countryCode = null;

        if (message.toLowerCase().contains(Constants.UK) || message.toLowerCase().contains(Constants.UNITED_KINGDOM)) countryCode = "1";
        if (message.toLowerCase().contains(Constants.FRANCE)) countryCode = "2";
        if (message.toLowerCase().contains(Constants.NETHERLANDS)) countryCode = "3";
        if (message.toLowerCase().contains(Constants.SPAIN)) countryCode = "4";
        if (message.toLowerCase().contains(Constants.AUSTRIA)) countryCode = "5";
        if (message.toLowerCase().contains(Constants.ITALY)) countryCode = "6";

        return countryCode;
    }

    public List<SearchHistory> getRecentSearch(Long userId, String sessionId) {
        return searchHistoryRepository.getRecentSearch(userId, sessionId);
    }

    public List<SessionIdResponse> getSessionId(Long userId) {
        List<SessionIdResponse> sessionIdResponseList = new ArrayList<>();
        var histories = searchHistoryRepository.getSessionId(userId);
        histories.forEach(data -> {
            SessionIdResponse sessionIdResponse = new SessionIdResponse(data.getSessionId(),
                    data.getSearchTime());
            sessionIdResponseList.add(sessionIdResponse);
        });
        return sessionIdResponseList;
    }

    public List<SearchHistory> getChatHistory(Long userId, String sessionId, String chatSessionId) {
        return searchHistoryRepository.getChatHistory(userId, sessionId, chatSessionId);
    }
}
