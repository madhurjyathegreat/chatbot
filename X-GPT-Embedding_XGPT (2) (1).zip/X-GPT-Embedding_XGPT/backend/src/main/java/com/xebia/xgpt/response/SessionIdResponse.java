package com.xebia.xgpt.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

public record SessionIdResponse(@JsonProperty("sessionId") String sessionId,
                                @JsonProperty("searchTime") Date searchTime) {
}
