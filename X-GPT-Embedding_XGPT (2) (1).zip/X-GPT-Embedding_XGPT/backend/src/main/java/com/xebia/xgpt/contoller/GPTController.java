package com.xebia.xgpt.contoller;

import com.xebia.xgpt.model.SearchHistory;
import com.xebia.xgpt.response.SessionIdResponse;
import com.xebia.xgpt.response.SuccessResponse;
import com.xebia.xgpt.services.GPTService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;

@Validated
@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class GPTController {
    @Autowired
    private final GPTService gptService;

    public GPTController(GPTService gptService) {
        this.gptService = gptService;
    }

    @GetMapping(value = "/getInfo")
    public Map<String, String> getInfoFromPython(@RequestParam("prompt") String prompt,
                                                 @RequestParam("message") String message,
                                                 @RequestParam("userId") Long userId,
                                                 @RequestParam("sessionId") String sessionId,
                                                 @RequestParam("chatSessionId") String chatSessionId) {
        try {
            return gptService.getInfo(prompt, message, userId, sessionId, chatSessionId);
        } catch (Exception e) {
            String errorMessage = "Some issues while getting data..!!";
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, errorMessage);
        }
    }

    @GetMapping(value = "/getPromptInfo")
    public List<String> getPromptInfoFromPython() {
        try {
            return gptService.getPromptInfo();
        } catch (Exception e) {
            String errorMessage = "Some issues while getting data..!!";
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, errorMessage);
        }
    }

    @PostMapping(value = "/addRecentSearch")
    public SuccessResponse addRecentSearch(@RequestParam("userId") Long userId,
                                           @RequestParam("sessionId") String loginSessionId,
                                           @RequestParam("message") String message,
                                           @RequestParam(value = "answer", required = false) String answer,
                                           @RequestParam(value = "chatSessionId", required = false) String chatSessionId) {
        return gptService.addRecentSearch(userId, loginSessionId, message, answer, chatSessionId);
    }

    @GetMapping(value = "/getRecentSearch")
    public List<SearchHistory> getRecentSearch(@RequestParam("userId") Long userId,
                                               @RequestParam("sessionId") String sessionId) {
        return gptService.getRecentSearch(userId, sessionId);
    }

    @GetMapping(value = "/getSessionId")
    public List<SessionIdResponse> getSessionId(@RequestParam("userId") Long userId) {
        return gptService.getSessionId(userId);
    }

    @GetMapping(value = "/getChatHistory")
    public List<SearchHistory> getChatHistory(@RequestParam("userId") Long userId,
                                              @RequestParam("sessionId") String sessionId,
                                              @RequestParam("chatSessionId") String chatSessionId) {
        return gptService.getChatHistory(userId, sessionId, chatSessionId);
    }
}
