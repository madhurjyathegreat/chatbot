package com.xebia.xgpt.exceptions;

public class DataNotFoundException extends RuntimeException{
    final String code;
    public DataNotFoundException(String message, String code) {
        super(message);
        this.code = code;
    }
}
