package com.xebia.xgpt.repository;

import com.xebia.xgpt.model.SearchHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;

public interface SearchHistoryRepository extends JpaRepository<SearchHistory, Long> {

    @Transactional
    @Modifying
    @Query(value = "insert into search_history (userid,session_id, recent_search, search_time, chatuser , chat_session_id)" +
            " values (:userId, :sessionId, :recentSearch, now(), :chatuser, :chatSessionId )"
            , nativeQuery = true)
    int saveRecentSearch(@Param("userId") Long userId,
                         @Param("sessionId") String loginSessionId,
                         @Param("recentSearch") String recentSearch,
                         @Param("chatuser") String chatuser,
                         @Param("chatSessionId") String chatSessionId);

    @Query(value = "select * from search_history where userid = :userId and session_id= :sessionId order by search_time desc",
            nativeQuery = true)
    List<SearchHistory> getRecentSearch(@Param("userId") Long userId,
                                        @Param("sessionId") String sessionId);

    @Query(value = "select * from search_history where userid = :userId group by session_id",
            nativeQuery = true)
    List<SearchHistory> getSessionId(@Param("userId") Long userId);

    @Query(value = "select * from search_history where userid = :userId and session_id= :sessionId and chat_session_id= :chatSessionId order by search_time desc",
            nativeQuery = true)
    List<SearchHistory> getChatHistory(@Param("userId") Long userId,
                                       @Param("sessionId") String sessionId,
                                       @Param("chatSessionId") String chatSessionId);

    @Query(value = "select * from search_history where userid = :userId and session_id= :sessionId and chat_session_id= :chatSessionId order by search_time",
            nativeQuery = true)
    List<SearchHistory> getChatHistoryByTime(@Param("userId") Long userId,
                                             @Param("sessionId") String sessionId,
                                             @Param("chatSessionId") String chatSessionId);
}
