package com.xebia.xgpt.jwt.constants;

public class ApplicationConstant {

    public static final String TOKEN_DONT_HAVE_ASSOCIATE_USER = "This token doesn't have associated user";
    public static final String ACCOUNT_NOT_ACTIVATED = "Account is not active";
    public static final String INVALID_TOKEN = "Token is invalid";
    public static final String USER_NOT_EXIST = "This user is not exist";
    public static final String INVALID_USER_CREDENTIALS = "Invalid user credentials";
    public static final String USER_EXISTS = "User already exists";
    public static final String ERROR_MESSAGE = "Something wrong happened";
    public static final String REGISTRATION_SUCCESS = "Registration Successful, Please login to continue.";
    public static final String USER_ACCOUNT_UPDATED = "User Account Update Successful";
    public static final String OPERATION_SUCCESS = "Operation Successful";
}
