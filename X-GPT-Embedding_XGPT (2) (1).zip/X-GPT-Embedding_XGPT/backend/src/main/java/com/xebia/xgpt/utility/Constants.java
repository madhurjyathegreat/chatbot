package com.xebia.xgpt.utility;

public class Constants {
    private Constants() {
        throw new IllegalStateException("Utility class");
    }
    public static final String EMPTY_STRING = "";
    public static final String COMMA = ",";
    public static final String UK = "uk";
    public static final String UNITED_KINGDOM = "united kingdom";
    public static final String NETHERLANDS = "netherlands";
    public static final String FRANCE = "france";
    public static final String ITALY = "italy";
    public static final String AUSTRIA = "austria";
    public static final String SPAIN = "spain";
}
