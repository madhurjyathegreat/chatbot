package com.xebia.xgpt.jwt.service;

import com.xebia.xgpt.jwt.emuns.UserStatus;
import com.xebia.xgpt.jwt.model.Role;
import com.xebia.xgpt.jwt.model.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class BootstrapService {
    private final String[] roles = {"XgptAdmin", "User", "BusinessUser", "ProjectAdmin"};
    @Autowired
    RoleService roleService;
    @Autowired
    UserService userService;

    @Transactional
    public void addRoles() {
        if (roleService.findByName("XgptAdmin") == null) {
            log.info("*************Inserting roles into DB*****************");
            roleService.addAll(getRoleList());
            log.info("*************Roles successfully updated into DB*****************");
        }
    }

    private List<Role> getRoleList() {
        List<Role> roleList = new ArrayList<>();
        for (String roleName : roles) {
            Role role = new Role();
            role.setName(roleName);
            roleList.add(role);
        }
        return roleList;
    }

    @Transactional
    public void addXgptAdmin() {
        if (userService.findUserByEmailId("admin@Xgpt.in") == null) {
            log.info("**********Adding Xgpt Admin in DB*************");
            userService.save(createXgptAdmin());
            log.info("**********Adding completed Xgpt Admin in DB*************");
        }
    }

    private User createXgptAdmin() {
        User user = new User();
        user.setFirstName("Xgpt");
        user.setLastName("Admin");
        user.setEmail("admin@xgpt.in");
        user.setStatus(UserStatus.ACTIVE);
        user.setPassword(new BCryptPasswordEncoder().encode("XgptAdmin@XEBIA2023"));
        user.setRole(roleService.findByName("XgptAdmin"));
        return user;
    }
}