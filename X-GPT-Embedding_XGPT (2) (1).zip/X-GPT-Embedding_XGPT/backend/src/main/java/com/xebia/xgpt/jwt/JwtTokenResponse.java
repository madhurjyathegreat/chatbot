package com.xebia.xgpt.jwt;

import com.xebia.xgpt.jwt.model.User;
import lombok.Data;

import java.io.Serializable;

@Data
public class JwtTokenResponse implements Serializable {
    private static final long serialVersionUID = 8317676219297719109L;
    private final String token;
    private final String email;
    private final Long id;
    private final String role;
    private final String firstName;
    private final String lastName;

    public JwtTokenResponse(String token, User user) {
        this.token = token;
        this.email = user.getEmail();
        this.id = user.getId();
        this.role = user.getRole().getName();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
    }
}
