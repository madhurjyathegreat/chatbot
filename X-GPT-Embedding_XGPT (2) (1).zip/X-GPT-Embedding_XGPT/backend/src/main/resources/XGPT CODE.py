from langchain.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import Chroma, FAISS
from langchain.embeddings import OpenAIEmbeddings

from langchain.embeddings import OpenAIEmbeddings, HuggingFaceInstructEmbeddings

embeddings = HuggingFaceInstructEmbeddings(model_name="intfloat/e5-base-v2")

db = Chroma(persist_directory=r"/Users/madhurjya.tamuly/Downloads/e5_embeddings_chroma", embedding_function=embeddings)

from langchain.chat_models import AzureChatOpenAI

llm = AzureChatOpenAI(
    openai_api_base='https://xgptopenai.openai.azure.com/',
    openai_api_version="2023-05-15",
    deployment_name='xgptopenai',
    openai_api_key='80e7759ef6a0414e9300f0d5a5f47991',
    openai_api_type="azure",
    temperature=0
)
from langchain.chains import RetrievalQA

qa_e5 = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db.as_retriever())  ##Model 1

embeddings_x1 = HuggingFaceInstructEmbeddings(model_name="hkunlp/instructor-xl")
db_x1 = FAISS.load_local("/Users/madhurjya.tamuly/Downloads/instructor_embeddings", embeddings_x1)

db_x1

qa_x1 = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db_x1.as_retriever())  ##Model 2


## Creating multi thead
def model1_run(query):
    qa_e5_response = qa_e5.run(query)
    return qa_e5_response


def model2_run(query):
    qa_x1_response = qa_x1.run(query)
    return qa_x1_response
    model1_run(query)


responses = ""


def bot():
    responses = ""
    while True:
        query = input("Ask you query:- ")
        response_model1 = model1_run(query + " according to our data")
        responses = responses + response_model1
        if "I'm sorry" in response_model1:
            response_model2 = model2_run(query + " according to our data")
            responses = responses + response_model2
            print(response_model2)
        else:
            print(response_model1)
