import pandas as pd
import sys
import os
import openai
from langchain.agents import create_csv_agent
from langchain.llms import OpenAI

api_key = "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"
# df = pd.read_csv("C:/workspace/X-GPT/backend/src/main/resources/prompts.csv")
# existing_actors = list(df["act"].str.lower().values)
prompts = ""

path="C:/workspace/X-GPT/backend/src/main/resources/XGPT_Travel.csv"

def call_gpt(message):
    os.environ["OPENAI_API_KEY"] = api_key
    agent = create_csv_agent(OpenAI(temperature=0.4),
                             path
                             )
    answer = agent.run(input=message)
    previous_answer = answer
    print(answer)
    return ""


if not sys.argv[1].lower() == "default":
    call_gpt("I Want you to Act as " + sys.argv[1] + " " + sys.argv[2])
else:
    call_gpt(sys.argv[2])
