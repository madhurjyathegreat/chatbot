from langchain.vectorstores import Chroma,FAISS
from langchain.embeddings import OpenAIEmbeddings,HuggingFaceInstructEmbeddings
import streamlit as st 
import pickle
from langchain.chains import RetrievalQA
from streamlit_chat import message
import sounddevice as sd
import numpy as np
from PIL import Image

st.set_page_config(layout="wide")
## Initiating the Azure llm
@st.cache_resource
def llm_pipeline():
    from langchain.chat_models import AzureChatOpenAI
    llm = AzureChatOpenAI(
        openai_api_base='https://xgptopenai.openai.azure.com/',
        openai_api_version="2023-05-15",
        deployment_name='xgptopenai',
        openai_api_key='174d1e2747d54e5291fa10b7f6cb8286',
        openai_api_type="azure",
        temperature=0
    )
    with st.spinner('Embeddings are in process...'):
        with open(r'/Users/madhurjya.tamuly/Downloads/embedings_e5.pkl', 'rb') as file:
            embeddings = pickle.load(file)
        #with open(r'/Users/madhurjya.tamuly/Downloads/embedings_x1.pkl', 'rb') as file:
            #embeddings_x1=pickle.load(file)
        with open(r'/Users/madhurjya.tamuly/Downloads/embedings_gte.pkl', 'rb') as file:
            embeddings_gte=pickle.load(file)
        with open(r'/Users/madhurjya.tamuly/Downloads/embedings_x1.pkl', 'rb') as file:
            embeddings_x1=pickle.load(file)
            
        #db_x1 = FAISS.load_local(r"/Users/madhurjya.tamuly/Downloads/instructor_embeddings", embeddings_x1)
        db = Chroma(persist_directory=r"/Users/madhurjya.tamuly/Downloads/e5_embeddings_chroma", embedding_function=embeddings)
        db_gte=Chroma(persist_directory=r"/Users/madhurjya.tamuly/Downloads/gte_embeddings_chroma", embedding_function=embeddings_gte)
        db_x1 = FAISS.load_local(r"/Users/madhurjya.tamuly/Downloads/instructor_embeddings", embeddings_x1)
    
    
        
        st.write("XEBIA BOT IS READY!!")
    return llm,db,db_gte,db_x1


    





def display_conversation(history):
    for i in range(len(history["generated"])):
        message(history["past"][i], is_user=True, key=str(i) + "_user")
        message(history["generated"][i],key=str(i))

## Creating multi thead
def model1_run(query,qa_e5):
    qa_e5_response=qa_e5.run(query)
    return qa_e5_response

def model2_run(query,qa_x1):
    qa_x1_response=qa_x1.run(query)
    return qa_x1_response

def model3_run(query,qa_gte):
    qa_gte_response=qa_gte.run(query)
    return qa_gte_response
    




def record_audio():
    duration = 5  # Duration of the recording in seconds
    fs = 44100    # Sampling frequency

    st.write("Recording...")

    # Record audio
    audio_data = sd.rec(int(duration * fs), samplerate=fs, channels=1)
    sd.wait()  # Wait for the recording to finish

    st.write("Recording complete.")

    return audio_data, fs


def logo(image_destination):
    custom_height = 100
    custom_width = 900
    logo_image = Image.open(image_destination)
    resized_logo = logo_image.resize((custom_width, custom_height))
    st.image(resized_logo, use_column_width=True)
    
    
def xebia_logo():
    # Load the Xebia logo image
    xebia_logo = r"/Users/madhurjya.tamuly/Desktop/xebia_logo.png"  # Replace with the actual logo image URL or path
    st.image(xebia_logo, use_column_width=False, width=50)


def main():
    if st.button("Record"):
        audio_data, fs = record_audio()
        st.audio(audio_data, format="wav", sample_rate=fs)
    
    xebia_logo()
    
    #llm=llm_pipeline()
    st.markdown("<h1 style='text-align: center; color: purple;'>XEBIA XGPT</h1>", unsafe_allow_html=True)
    # Initialize session state for generated responses and past messages
    #user_input = st.text_input("", key="input")
    llm,db,db_gte,db_x1=llm_pipeline()
    
    query=st.chat_input("Ask something")
    
    
    if "generated" not in st.session_state:
        st.session_state["generated"] = ["I am XEBIA'S BOT.Let me help you"]
    if "past" not in st.session_state:
        st.session_state["past"] = ["Hey there!"]
        st.session_state["response"]=["start"]
    
    


    
    if query:
        st.session_state["past"].append(query)
        responses=" ".join([i for i in st.session_state['response']])    
        
        if 'france' in query.lower() or 'france' in responses.lower() or  'united kingdom' in query.lower() or 'united kingdom' in responses.lower() or 'uk' in query.lower() or 'uk' in responses.lower():
            if ('netherlands' in query.lower() or 'netherlands' in responses.lower()) or ('italy' in query.lower() or 'italy' in responses.lower()) or ('spain' in query.lower() or 'spain' in responses.lower()):
                #message("inside netherlands")
                #responses=""
                
                qa = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db.as_retriever())
                reply=qa.run(responses+" "+query)
                st.session_state["response"].append(reply)
                st.session_state["generated"].append(reply) 
            else:
                #message("inside uk")
                qa_gte = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db_gte.as_retriever())
                reply=qa_gte.run(responses+" "+query)
                st.session_state["response"].append(reply)
                st.session_state["generated"].append(reply)
                    
        else:
            qa = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db.as_retriever())
            reply=qa.run(responses+" "+query)
            st.session_state["response"].append(reply)
            st.session_state["generated"].append(reply) 
                
    if st.session_state["generated"]:
        display_conversation(st.session_state)
                        
        
   
            
        
    
    
        
    
        
    

    
if __name__ == "__main__":
    main()

