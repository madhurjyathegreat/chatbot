from functools import lru_cache
from langchain.chains import RetrievalQA
import sys


@lru_cache(maxsize=None)
def loading_resources():
    from langchain.chat_models import AzureChatOpenAI

    from langchain.vectorstores import FAISS

    import pickle

    llm = AzureChatOpenAI(

        openai_api_base='https://xgptopenai.openai.azure.com/',

        openai_api_version="2023-05-15",

        deployment_name='xgptopenai',

        openai_api_key='174d1e2747d54e5291fa10b7f6cb8286',

        openai_api_type="azure",

        temperature=0

    )

    with open(r'C:\workspace\X-GPT\backend\src\main\resources\embeddings_faiss_gte.pkl', 'rb') as file:
        embeddings_faiss_gte_uk = pickle.load(file)

    db_faiss_gte_uk = FAISS.load_local(r'C:\workspace\X-GPT\backend\src\main\resources\db_faiss_gte',
                                       embeddings_faiss_gte_uk)

    db_faiss_gte_othercountries = FAISS.load_local(
        r'C:\workspace\X-GPT\backend\src\main\resources\db_faiss_gte_othercountries', embeddings_faiss_gte_uk)

    return llm, db_faiss_gte_uk, db_faiss_gte_othercountries


def model_initialite(llm, db_faiss_gte_uk, db_faiss_gte_othercountries, message):
    if 'france' in message.lower() or 'united kingdom' in message.lower() or 'uk' in message.lower():

        if ('netherlands' in message.lower()) or ('italy' in message.lower()) or ('spain' in message.lower()):

            qa = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff",
                                             retriever=db_faiss_gte_othercountries.as_retriever())

            print(qa.run(message + " according to the dataset"))

        else:

            qa_gte = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db_faiss_gte_uk.as_retriever())

            print(qa_gte.run(message + " according to the dataset"))

    else:

        qa = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff",
                                         retriever=db_faiss_gte_othercountries.as_retriever())

        print(qa.run(message + " according to the dataset"))


def main(message):
    llm, db_faiss_gte_uk, db_faiss_gte_othercountries = loading_resources()

    model_initialite(llm, db_faiss_gte_uk, db_faiss_gte_othercountries, message)


if __name__ == "__main__":
    if not sys.argv[1].lower() == "default":
        pass  # call_gpt("I Want you to Act as " + sys.argv[1] + " " + sys.argv[2])
    else:
        main(sys.argv[2])
