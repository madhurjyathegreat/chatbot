from langchain.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import Chroma,FAISS
from langchain.embeddings import OpenAIEmbeddings

from langchain.embeddings import OpenAIEmbeddings, HuggingFaceInstructEmbeddings
embeddings = HuggingFaceInstructEmbeddings(model_name="intfloat/e5-base-v2")

db = Chroma(persist_directory=r"/Users/madhurjya.tamuly/Downloads/e5_embeddings_chroma", embedding_function=embeddings)


from langchain.chat_models import AzureChatOpenAI
llm = AzureChatOpenAI(
        openai_api_base='https://xgptopenai.openai.azure.com/',
        openai_api_version="2023-05-15",
        deployment_name='xgptopenai',
        openai_api_key='174d1e2747d54e5291fa10b7f6cb8286',
        openai_api_type="azure",
        temperature=0
    )
from langchain.chains import RetrievalQA


embeddings_x1 = HuggingFaceInstructEmbeddings(model_name="hkunlp/instructor-xl")
db_x1 = FAISS.load_local("/Users/madhurjya.tamuly/Downloads/instructor_embeddings", embeddings_x1)

embeddings_gte=HuggingFaceInstructEmbeddings(model_name="thenlper/gte-large")
db_gte=Chroma(persist_directory=r"/Users/madhurjya.tamuly/Downloads/gte_embeddings_chroma", embedding_function=embeddings_gte)

qa_e5 = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db.as_retriever())##Model 1

qa_x1 = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db_x1.as_retriever())##Model 2

qa_gte = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db_gte.as_retriever())##Model 3


## Creating multi thead
def model1_run(query):
    qa_e5_response=qa_e5.run(query)
    return qa_e5_response

def model2_run(query):
    qa_x1_response=qa_x1.run(query)
    return qa_x1_response
    
    
def model3_run(query):## for uk and france
    qa_gte_response=qa_gte.run(query)
    return qa_gte_response

global_list=[]
def primary_response():
    responses=""
    responses_m1="netherlands,italy,spain"
    responses_rest=""
    while True:
        query=input("Ask you query:- ")
        if 'france' in query.lower() or 'france' in responses.lower() or  'united kingdom' in query.lower() or 'united kingdom' in responses.lower() or 'uk' in query.lower() or 'uk' in responses.lower():
            
            if ('netherlands' in query.lower() and 'netherlands' in responses_m1.lower()) or ('italy' in query.lower() and 'italy' in responses_m1.lower()) or ('spain' in query.lower() and 'spain' in responses_m1.lower()):
                #print("inside if")
                response_model1=model1_run(responses_m1+" "+query+" according to the data")
                responses_m1=responses_m1+"The question is "+query+".The answer is"+response_model1
                if "I'm sorry" in response_model1:
                    response_model2=model2_run(responses_m1+" "+query+" according to the data")
                    responses_m1=responses_m1+"The question is "+query+".The answer is"+response_model2
                    print(response_model2)
                else:
                    print(response_model1)
            else:
                #print("else part")
                response_model3=model3_run(responses+" "+query+" according to the data")
                responses=responses+"The question is "+query+".The answer is"+response_model3
                print(response_model3)
        else:
            response_model1=model1_run(responses_rest+" "+query+" according to the data")
            responses_rest=responses_rest+"The question is "+query+".The answer is"+response_model1
            if "I'm sorry" in response_model1:
                response_model2=model2_run(responses_rest+" "+query+" according to the data")
                responses_rest=responses_rest+"The question is "+query+".The answer is"+response_model2
                print(response_model2)
            else:
                print(response_model1)

        global_list.append(responses)
        
primary_response()      
        
