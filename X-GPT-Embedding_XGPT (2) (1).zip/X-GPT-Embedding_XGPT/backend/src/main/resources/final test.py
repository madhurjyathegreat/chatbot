import pickle
import sys

from langchain.chains import RetrievalQA
from langchain.vectorstores import FAISS

with open(r'C:\workspace\X-GPT\backend\src\main\resources\embeddings_f_bge.pkl', 'rb') as file:
    embeddings_f_bge = pickle.load(file)

# embeddings = HuggingFaceInstructEmbeddings(model_name="BAAI/bge-large-en")

from functools import lru_cache


@lru_cache(maxsize=None)
def call_gpt(clubbedmessage, message, country_code):
    # new_db = FAISS.load_local(r"C:\workspace\X-GPT\backend\src\main\resources\db_all_countries1", embeddings)
    from langchain.chat_models import AzureChatOpenAI
    llm = AzureChatOpenAI(
        openai_api_base='https://xgptopenai.openai.azure.com/',
        openai_api_version="2023-05-15",
        deployment_name='xgptopenai',
        openai_api_key='174d1e2747d54e5291fa10b7f6cb8286',
        openai_api_type="azure",
        temperature=0

    )

    """Code for switching models according to country"""
    if country_code == "1":  ##uk
        uk_base_sep = FAISS.load_local(r"C:\workspace\X-GPT\backend\src\main\resources\sep_models\uk_base_sep",
                                       embeddings_f_bge)
        qa_uk = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff",
                                            retriever=uk_base_sep.as_retriever(search_kwargs={'fetch_k': 800, 'k': 50}),
                                            return_source_documents=True)
        result = qa_uk({"query": clubbedmessage + " " + message + " according to our dataset"})
        print(result['result'])
    elif country_code == "2":  ##france
        france_base_sep = FAISS.load_local(r"C:\workspace\X-GPT\backend\src\main\resources\sep_models\france_base_sep",
                                           embeddings_f_bge)
        qa_france = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=france_base_sep.as_retriever(
            search_kwargs={'fetch_k': 800, 'k': 50}), return_source_documents=True)
        result = qa_france({"query": clubbedmessage + " " + message + " according to our dataset"})
        print(result['result'])
    elif country_code == "3":  ###netherlands
        netherlands_base_sep = FAISS.load_local(
            r"C:\workspace\X-GPT\backend\src\main\resources\sep_models\netherlands_base", embeddings_f_bge)
        qa_netherlands = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff",
                                                     retriever=netherlands_base_sep.as_retriever(
                                                         search_kwargs={'fetch_k': 800, 'k': 50}),
                                                     return_source_documents=True)
        result = qa_netherlands({"query": clubbedmessage + " " + message + " according to our dataset"})
        print(result['result'])
    elif country_code == "4":  ###spain
        spain_base_sep = FAISS.load_local(r"C:\workspace\X-GPT\backend\src\main\resources\sep_models\spain_base",
                                          embeddings_f_bge)
        qa_spain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=spain_base_sep.as_retriever(
            search_kwargs={'fetch_k': 800, 'k': 50}), return_source_documents=True)
        result = qa_spain({"query": clubbedmessage + " " + message + " according to our dataset"})
        print(result['result'])
    elif country_code == "5":  ###austria
        austria_base_sep = FAISS.load_local(r"C:\workspace\X-GPT\backend\src\main\resources\sep_models\austria_base",
                                            embeddings_f_bge)
        qa_austria = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=austria_base_sep.as_retriever(
            search_kwargs={'fetch_k': 800, 'k': 50}), return_source_documents=True)
        result = qa_austria({"query": clubbedmessage + " " + message + " according to our dataset"})
        print(result['result'])
    elif country_code == "6":  ###italy
        italy_base_sep = FAISS.load_local(r"C:\workspace\X-GPT\backend\src\main\resources\sep_models\italy_base",
                                          embeddings_f_bge)
        qa_italy = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=italy_base_sep.as_retriever(
            search_kwargs={'fetch_k': 800, 'k': 50}), return_source_documents=True)
        result = qa_italy({"query": clubbedmessage + " " + message + " according to our dataset"})
        print(result['result'])

    # result = qa({"query": clubbedmessage + " " + message + " according to our dataset"})
    # print(result['result'])
    return ""


if not sys.argv[1].lower() == "default":
    call_gpt("I Want you to Act as " + sys.argv[1] + " " + sys.argv[2])
else:
    call_gpt(sys.argv[2], sys.argv[3], sys.argv[4])
