import { Component } from '@angular/core';
import { CommonService } from './services/common/common.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'project';

constructor(public common: CommonService) {
    // localStorage.removeItem("userName");
    // localStorage.removeItem("firstName");
    // localStorage.removeItem("lastName");
    
  }
}
