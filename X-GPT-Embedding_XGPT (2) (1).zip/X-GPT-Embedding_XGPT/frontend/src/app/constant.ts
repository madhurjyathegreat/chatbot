export const layouts = [
    {
        "name": "Arabic",
        "value": "arabic"
    },
    // {
    //     "name": "assamese",
    //     "value": "assamese"
    // },

    // {
    //     "name": "balochi",
    //     "value": "balochi"
    // },

    // {
    //     "name": "belarusian",
    //     "value": "belarusian"
    // },

    // {
    //     "name": "bengali",
    //     "value": "bengali"
    // },

    // {
    //     "name": "brazilian",
    //     "value": "brazilian"
    // },

    // {
    //     "name": "burmese",
    //     "value": "burmese"
    // },

    // {
    //     "name": "chinese",
    //     "value": "chinese"
    // },
    // {
    //     "name": "czech",
    //     "value": "czech"
    // },

    {
        "name": "English",
        "value": "english"
    },
    // {
    //     "name": "farsi",
    //     "value": "farsi"
    // },

    {
        "name": "French",
        "value": "french"
    },
    // {
    //     "name": "georgian",
    //     "value": "georgian"
    // },

    {
        "name": "German",
        "value": "german"
    },

    // {
    //     "name": "gilaki",
    //     "value": "gilaki"
    // },

    // {
    //     "name": "greek",
    //     "value": "greek"
    // },

    // {
    //     "name": "hebrew",
    //     "value": "hebrew"
    // },
    // {
    //     "name": "hindi",
    //     "value": "hindi"
    // },

    // {
    //     "name": "hungarian",
    //     "value": "hungarian"
    // },
    // {
    //     "name": "italian",
    //     "value": "italian"
    // },
    // {
    //     "name": "japanese",
    //     "value": "japanese"
    // },
    // {
    //     "name": "kannada",
    //     "value": "kannada"
    // },
    // {
    //     "name": "korean",
    //     "value": "korean"
    // },
    // {
    //     "name": "kurdish",
    //     "value": "kurdish"
    // },
    // {
    //     "name": "malayalam",
    //     "value": "malayalam"
    // },
    // {
    //     "name": "nigerian",
    //     "value": "nigerian"
    // },
    // {
    //     "name": "nko",
    //     "value": "nko"
    // },
    // {
    //     "name": "norwegian",
    //     "value": "norwegian"
    // },
    // {
    //     "name": "odia",
    //     "value": "odia"
    // },
    // {
    //     "name": "polish",
    //     "value": "polish"
    // },
    // {
    //     "name": "punjabi",
    //     "value": "punjabi"
    // },

    // {
    //     "name": "russian",
    //     "value": "russian"
    // },
    // {
    //     "name": "russianOld",
    //     "value": "russianOld"
    // },
    // {
    //     "name": "sindhi",
    //     "value": "sindhi"
    // },

    {
        "name": "Spanish",
        "value": "spanish"
    },
    {
        "name": "Swedish",
        "value": "swedish"
    },
    // {
    //     "name": "telugu",
    //     "value": "telugu"
    // },
    // {
    //     "name": "thai",
    //     "value": "thai"
    // },
    // {
    //     "name": "turkish",
    //     "value": "turkish"
    // },
    // {
    //     "name": "ukrainian",
    //     "value": "ukrainian"
    // },
    // {
    //     "name": "urdu",
    //     "value": "urdu"
    // },
    // {
    //     "name": "urduStandard",
    //     "value": "urduStandard"
    // },
    // {
    //     "name": "uyghur",
    //     "value": "uyghur"
    // }
]

export const avatarsArray = [
    { path: "assets/avtars/avatar.png"},
    { path: "assets/avtars/boy.png"},
    { path: "assets/avtars/cat.png"},
    { path: "assets/avtars/empathy.png"},
    { path: "assets/avtars/gamer_7.png"},
    { path: "assets/avtars/gamer.png"},
    { path: "assets/avtars/girl_2.png"},
    { path: "assets/avtars/girl.png"},
    { path: "assets/avtars/hacker.png"},
    { path: "assets/avtars/man_1.png"},
    { path: "assets/avtars/man_2.png"},
    { path: "assets/avtars/man_3.png"},
    { path: "assets/avtars/man_4.png"},
    { path: "assets/avtars/man_5.png"},
    { path: "assets/avtars/man_6.png"},
    { path: "assets/avtars/man_7.png"},
    { path: "assets/avtars/man_8.png"},
    { path: "assets/avtars/man.png"},
    { path: "assets/avtars/panda.png"},
    { path: "assets/avtars/profile.png"},
    { path: "assets/avtars/user_1.png"},
    { path: "assets/avtars/user.png"},
    { path: "assets/avtars/woman_1.png"},
    { path: "assets/avtars/woman_2.png"},
    { path: "assets/avtars/woman_3.png"},
    { path: "assets/avtars/woman.png"},
]