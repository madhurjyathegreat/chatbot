import { Injectable } from "@angular/core";

@Injectable()
export class apiList {

  login: string = "api/xgpt/v1/authenticate";
  regiser: string = "api/xgpt/v1/public/register";
  forgot: string = "api/xgpt/v1/public/forgot-password?email=";
  reset: string = "api/xgpt/v1/public/reset-password?token=";
  suggestions: string = "api/v1/getPromptInfo";
  search: string = "api/v1/getInfo?prompt=";
  saveRecentSearch: string = "api/v1/addRecentSearch?userId=";
  getRecentSearch: string = "api/v1/getRecentSearch?userId=";
  getSessionId: string = "api/v1/getSessionId?userId=";
  getChatHistory: string ="api/v1/getChatHistory?userId="
}
