import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { apiList } from "./api-list";
import { BehaviorSubject, Observable } from "rxjs";
import { CommonService } from "../common/common.service";

@Injectable({
  providedIn: "root",
})
export class HttpsService {
  baseUrl: string = environment.baseUrl;

  constructor(private http: HttpClient, private apiList: apiList, private common: CommonService) { }


  httpPost(url: string, params: any): Observable<Object> {
    // return this.http.post(this.baseUrl + this.apiList[url], params);
    return this.http.post(this.baseUrl + url, params);
  }

  httpPutWithHeader(url: string, params: any): Observable<Object> {
    // return this.http.put(this.baseUrl + this.apiList[url], params, this.header());
    return this.http.put(this.baseUrl + url, params, this.header());
  }

  httpPostWithHeader(url: string, params: any): Observable<Object> {
    // return this.http.post(this.baseUrl + this.apiList[url], params, this.header());
    return this.http.post(this.baseUrl + url, params, this.header());
  }

  httpGetWithHeader(url: string, params: any): Observable<Object> {
    // return this.http.get(this.baseUrl + this.apiList[url] + "?" + params, this.header());
    return this.http.get((this.baseUrl + url) + (params ? ("?" + params) : ''), this.header());
  }

  httpGetWithHeaderAndBody(url: string, params: any): Observable<Object> {
    // return this.http.get(this.baseUrl + this.apiList[url] + "?" + params, this.header());
    return this.http.get((this.baseUrl + url), params);
  }

  httpGetWithHeaderId(url: string, params: any): Observable<Object> {
    // return this.http.get(this.baseUrl + this.apiList[url] + "/" + params, this.header());
    return this.http.get(this.baseUrl + url + "/" + params, this.header());
  }

  httpGet(url: string, link: string): Observable<Object> {
    // return this.http.get(this.baseUrl + this.apiList[url] + link);
    return this.http.get(this.baseUrl + url + link);
  }

  httpDeleteWithHeader(url: string, data: any): Observable<Object> {
    // return this.http.delete(this.baseUrl + this.apiList[url] + "/" + id, this.header());
    return this.http.post(this.baseUrl + url, data, this.header());
  }

  httpPostWithHeaderAndFile(url: string, formData: FormData): Observable<Object> {
    const headers = new HttpHeaders({
      mimeType: "multipart/form-data",
      authorization: 'Bearer ' + localStorage.getItem('accessToken') || '',
    });
    const headersObj = { headers };
    // return this.http.post(this.baseUrl + this.apiList[url], formData, headersObj);
    return this.http.post(this.baseUrl + url, formData, headersObj);
  }

  // fileUpload(fileData: any) {
  //   var formData = new FormData();
  //   formData.append("file", fileData, fileData.name);
  //   const headers = new HttpHeaders({
  //     mimeType: "multipart/form-data",
  //     // authorization: 'Bearer '+ localStorage.getItem('accessToken') || '',
  //   });
  //   const headersObj = { headers };
  //   return this.http.post(this.baseUrl + this.apiList["uploadFile"], formData, headersObj);
  // }

  header() {
    // if (localStorage.getItem('accessToken') != undefined || localStorage.getItem('accessToken') != null) {
    const headers = new HttpHeaders({
      "cache-control": "no-cache",
      "content-type": "application/json",
      // authorization: 'Bearer '+ localStorage.getItem('accessToken') || '',
    });
    const option = {
      headers,
    };
    return option;
    // }
  }

  getCountries() {
    return this.http.get("https://countriesnow.space/api/v0.1/countries/currency");
  }

  getStates(data: any) {
    return this.http.post("https://countriesnow.space/api/v0.1/countries/states", data);
  }

  getCitiesByState(data: any) {
    return this.http.post("https://countriesnow.space/api/v0.1/countries/state/cities", data);
  }

  getLocations(data: any) {
    return this.http.post("https://countriesnow.space/api/v0.1/countries/cities", data);
  }

  unsubscribeUser(url: string, link: string): Observable<Object> {
    return this.http.get(this.baseUrl + url + '/' + link);
  }
}
