import { Injectable } from '@angular/core';
import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router, CanDeactivate} from '@angular/router';
import { Observable } from 'rxjs';
import {CommonService} from "../common/common.service";

@Injectable({
  providedIn: 'root'
})
export class GuardService implements CanActivate {
  constructor(
    private router: Router,
    private common: CommonService
  ) {
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (!localStorage.getItem('accessToken')) {
      this.router.navigateByUrl('/operators-desk/auth/login');
      return false;
    }
    return true;
    // return true;
  }

}