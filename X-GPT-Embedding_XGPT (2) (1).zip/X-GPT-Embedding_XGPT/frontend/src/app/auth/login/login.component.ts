import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common/common.service';
import { apiList } from 'src/app/services/https/api-list';
import { HttpsService } from 'src/app/services/https/https.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['../auth.component.scss']
})
export class LoginComponent {
  userName!: string;
  password!: string;

  constructor(private https: HttpsService, private apilist: apiList, private common: CommonService, private router: Router) {

  }

  openXebia() {
    window.open("https://xebia.com", "_blank");
  }

  submit() {
    if (!this.userName) {
      return this.common.presentsToast('error', 'top-end', 'Email is required');
    }
    if (!this.password) {
      return this.common.presentsToast('error', 'top-end', 'Password is required');
    }
    let data: any = {
      userName: this.userName,
      password: this.password
    }
    this.https.httpPost(this.apilist.login, data).subscribe((res: any) => {
      if (res && res.token) {
        let today = new Date();
        const currentMonth = today.getMonth() + 1;
        let timestamp = `${today.getDate()}/${currentMonth}/${today.getFullYear()}`;
        localStorage.setItem("accessToken", res.token);
        localStorage.setItem("userId", res.id);
        localStorage.setItem("sessionId", timestamp)
        localStorage.setItem("userName", this.userName)
        localStorage.setItem("userDetail", JSON.stringify({ firstName: res.firstName, lastName: res.lastName }))
        this.router.navigateByUrl("/home");
      }
    })
  }

}
