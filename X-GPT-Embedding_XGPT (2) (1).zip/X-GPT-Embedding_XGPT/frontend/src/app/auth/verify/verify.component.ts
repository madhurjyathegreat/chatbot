import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common/common.service';
import { apiList } from 'src/app/services/https/api-list';
import { HttpsService } from 'src/app/services/https/https.service';

@Component({
  selector: 'app-verify',
  templateUrl: './verify.component.html',
  styleUrls: ['../auth.component.scss']
})
export class VerifyComponent {
  userName!:string;
  firstName!:string;
  lastName!:string;
  password!:string;

  constructor(private https: HttpsService, private apilist: apiList, private common: CommonService, private router: Router) {
    if(localStorage.getItem("userName")) {
      this.userName = localStorage.getItem("userName")||"";
    } else {
      this.router.navigateByUrl("/signup");
    }
    if(localStorage.getItem("firstName")) {
      this.firstName = localStorage.getItem("firstName")||"";
    } else {
      this.router.navigateByUrl("/profile");
    }
    if(localStorage.getItem("lastName")) {
      this.lastName = localStorage.getItem("lastName")||"";
    } else {
      this.router.navigateByUrl("/profile");
    }
  }

  submit() {
    if(!this.userName) {
      this.common.presentsToast('error','top-end','Email is required');
      this.router.navigateByUrl("/signup");
    }
    if(!this.firstName) {
      this.common.presentsToast('error','top-end','Firstname is required');
      this.router.navigateByUrl("/profile");
    }
    if(!this.lastName) {
      this.common.presentsToast('error','top-end','Lastname is required');
      this.router.navigateByUrl("/profile");
    }
    if(!this.password) {
      return this.common.presentsToast('error','top-end','Password is required');
    }
    let data:any = {
      email: this.userName,
      firstName: this.firstName,
      lastName: this.lastName,
      password: this.password
    }
    this.https.httpPost(this.apilist.regiser, data).subscribe((res:any) => {
      if(res&&res.status) {
        this.common.presentsToast("success","top-end",res.message);
        this.router.navigateByUrl("/login");
        // this.login();
      }
    })
  }

  login() {
    let data:any = {
      userName: this.userName,
      password: this.password
    }
    this.https.httpPost(this.apilist.login, data).subscribe((res:any) => {
      if(res&&res.token) {
        localStorage.setItem("accessToken",res.token);
        this.router.navigateByUrl("/home");
      }
    })
  }
}
