import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common/common.service';
import { apiList } from 'src/app/services/https/api-list';
import { HttpsService } from 'src/app/services/https/https.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['../auth.component.scss']
})
export class SignupComponent {
  userName!:string;
  password!:string;

  constructor(private https: HttpsService, private apilist: apiList, private common: CommonService, private router: Router) {
    if(localStorage.getItem("userName")) {
      this.userName = localStorage.getItem("userName")||"";
    }
  }

  next() {
    if(!this.userName) {
      return this.common.presentsToast('error','top-end','Email is required');
    }
    localStorage.setItem("userName", this.userName);
    this.router.navigateByUrl("/profile");
  }
}
