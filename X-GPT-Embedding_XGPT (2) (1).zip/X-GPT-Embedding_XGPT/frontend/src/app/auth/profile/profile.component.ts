import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common/common.service';
import { apiList } from 'src/app/services/https/api-list';
import { HttpsService } from 'src/app/services/https/https.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['../auth.component.scss']
})
export class ProfileComponent {
  userName!:string;
  firstName!:string;
  lastName!:string;

  constructor(private https: HttpsService, private apilist: apiList, private common: CommonService, private router: Router) {
    if(localStorage.getItem("userName")) {
      this.userName = localStorage.getItem("userName")||"";
    } else {
      this.router.navigateByUrl("/signup");
    }
    if(localStorage.getItem("firstName")) {
      this.firstName = localStorage.getItem("firstName")||"";
    }
    if(localStorage.getItem("lastName")) {
      this.lastName = localStorage.getItem("lastName")||"";
    }
  }

  next() {
    if(!this.userName) {
      this.common.presentsToast('error','top-end','Email is required');
      this.router.navigateByUrl("/signup");
    }
    if(!this.firstName) {
      return this.common.presentsToast('error','top-end','Firstname is required');
    }
    if(!this.lastName) {
      return this.common.presentsToast('error','top-end','Lastname is required');
    }
    localStorage.setItem("firstName", this.firstName);
    localStorage.setItem("lastName", this.lastName);
    this.router.navigateByUrl("/verify");
  }
}
