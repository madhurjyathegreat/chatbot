import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common/common.service';
import { apiList } from 'src/app/services/https/api-list';
import { HttpsService } from 'src/app/services/https/https.service';
import { AvatarDialogComponent } from '../avatar-box/avatar-dialog/avatar-dialog.component';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  id: any;
  sessionId: any = '';
  result: any[] = [];
  sessions: any[] = [];
  darkMode: boolean = false;
  panelOpenState = false;
  sessions2: any = {};
  userName = localStorage.getItem("userName");
  constructor(
    private https: HttpsService, 
    private apilist: apiList, 
    private common: CommonService,
     private router: Router,
    private dialog: MatDialog) {
    if (localStorage.getItem("userId")) {
      this.id = localStorage.getItem("userId");
    }
    if (localStorage.getItem("sessionId")) {
      this.sessionId = localStorage.getItem("sessionId");
    }
    //this.getRecentHistory();
    this.getSessionId();
    this.common.isSearchChange.subscribe((res: any) => {
      if (res) {
        if (localStorage.getItem("userId")) {
          this.id = localStorage.getItem("userId");
        }
        if (localStorage.getItem("sessionId")) {
          this.sessionId = localStorage.getItem("sessionId");
        }
        // !this.checkSession() && this.getSessionId();
        this.getSessionId();
        // this.getRecentHistory();
      }
    })
  }
  checkSession() {
    let isThere: boolean = false;
    this.sessions.filter((item: any) => {
      if (this.sessionId === item.sessionId) isThere = true;
    });
    return isThere;
  }
  getSessionId() {
    this.https.httpGetWithHeader(this.apilist.getSessionId + this.id, '').subscribe((res: any) => {
      if (res) {
        let response: any[] = [];
        response = res;
        this.sessions = response.reverse();
        // for (const session of response) {
        //   this.getRecentHistory2(session.sessionId).subscribe((res: any) => {
        //     if (res) {

        //       if (!this.sessions[session.sessionId]) {
        //         this.sessions[session.sessionId] = [];
        //       }
        //       this.sessions[session.sessionId]=res;
        //     }
        //   });
        // }>
        this.sessions = this.sessions.map((item: any) => {
          const newItem = { ...item }
          this.getRecentHistory2(newItem.sessionId).subscribe((res: any) => {
            if (res) {
              newItem.sessionArray = res;
            }
          });
          return newItem
        })
      }
    });
  }

  getRecentHistory(sessionId: string) {
    this.https.httpGetWithHeader(this.apilist.getRecentSearch + this.id + '&sessionId=' + this.sessionId, '').subscribe((res: any) => {
      if (res) {
        this.result = res;
      }
    });
  }
  getRecentHistory2(sessionId: string) {
    return this.https.httpGetWithHeader(this.apilist.getRecentSearch + this.id + '&sessionId=' + sessionId, '');
  }

  searchAgain(item: any) {
    this.common.searchData.next(item);
  }

  logout() {
    localStorage.clear();
    this.router.navigateByUrl("/login");
  }

  utcToIst(date: any) {
    // return date;
    var dateUTC = new Date(date);
    var dateIST = new Date(dateUTC.getTime());
    //date shifting for IST timezone (+5 hours and 30 minutes)
    dateIST.setHours(dateIST.getHours() - 5);
    dateIST.setMinutes(dateIST.getMinutes() - 30);
    return dateIST;
  }

  changeMode() {
    this.darkMode = !this.darkMode;
    this.common.darkMode.next(this.darkMode);
  }

  showAvatar() {
    const avatarDialogRef = this.dialog.open(AvatarDialogComponent, {
      width: ' 450px',
    })
    avatarDialogRef.afterClosed().subscribe((data) => {
      console.log("data.path::>>", data.path)
      // this.avatarImagePath = data.path;
      this.common.getGptAvatar.next(data.path)
    });
  }
}
