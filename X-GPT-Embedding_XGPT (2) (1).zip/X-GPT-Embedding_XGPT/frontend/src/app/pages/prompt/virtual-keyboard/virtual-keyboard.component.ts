import { Component, ViewEncapsulation } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import Keyboard from "simple-keyboard";
import KeyboardLayouts from "simple-keyboard-layouts";
import { layouts } from "../../../constant"
@Component({
  selector: 'app-virtual-keyboard',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './virtual-keyboard.component.html',
  styleUrls: ['./virtual-keyboard.component.scss']
})
export class VirtualKeyboardComponent {
  value = "";
  keyboard!: Keyboard;
  keyboardLayouts: any;
  layouts = layouts;
  layoutsObj: any;
  selectedLayout: string = "english";

  constructor(public dialogRef: MatDialogRef<VirtualKeyboardComponent>) {
    this.keyboardLayouts = new KeyboardLayouts();
    this.layoutsObj = this.keyboardLayouts.get();
  }
  ngOnInit(): void {
    this.keyboard = new Keyboard({
      onChange: (input: string) => this.onChange(input),
      onKeyPress: (button: string) => this.onKeyPress(button),
      layout: this.layoutsObj[this.selectedLayout].layout
    }
    );
  }

  onChange = (input: string) => {
    this.value = input;
  };

  onKeyPress = (button: string) => {
      /**
     * If you want to handle the shift and caps lock buttons
     */
    if (button === "{shift}" || button === "{lock}") this.handleShift();
    // if (button === "{enter}" && this.value !== "") {
    //   this.dialogRef.close({
    //     textValue: this.value,
    //   });
    // }
  };

  onInputChange = (event: any) => {
    this.value = event.target.value
    this.keyboard.setInput(event.target.value);
  };

  onSelectChange = (event: any) => {
    let value = event.value;
    this.selectedLayout = value;
    this.keyboard?.setOptions({
      layout: this.layoutsObj[this.selectedLayout].layout
    });
  };

  handleShift = () => {
    let currentLayout = this.keyboard?.options.layoutName;
    let shiftToggle = currentLayout === "default" ? "shift" : "default";
    this.keyboard?.setOptions({
      layoutName: shiftToggle
    });
  };

  onSend(){
    if (this.value){

      this.dialogRef.close({
          textValue: this.value,
        });
    }
  }

}
