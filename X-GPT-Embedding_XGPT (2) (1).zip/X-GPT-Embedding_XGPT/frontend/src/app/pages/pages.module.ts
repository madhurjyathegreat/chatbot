import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatMenuModule } from '@angular/material/menu';
import { PagesRoutingModule } from './pages-routing.module';
import { PagesComponent } from './pages.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HomeComponent } from './home/home.component';
import {MatIconModule} from '@angular/material/icon';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatTreeModule} from '@angular/material/tree';
import {MatExpansionModule} from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { VirtualKeyboardComponent } from './prompt/virtual-keyboard/virtual-keyboard.component';
import { MatDialogModule } from '@angular/material/dialog';
import { AvatarDialogComponent } from './avatar-box/avatar-dialog/avatar-dialog.component';
import { MatSelectModule } from '@angular/material/select';
import { PromptComponent } from './prompt/prompt.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AvatarBoxComponent } from './avatar-box/avatar-box.component';
import { HistoryComponent } from './history/history.component';
import { MenuDialogComponent } from './menu-dialog/menu-dialog.component';

@NgModule({
  declarations: [
    PagesComponent,
    SidebarComponent,
    HomeComponent,
    VirtualKeyboardComponent,
    AvatarDialogComponent,
    PromptComponent,
    HeaderComponent,
    FooterComponent,
    AvatarBoxComponent,
    HistoryComponent,
    MenuDialogComponent
  ],
  imports: [
    CommonModule,
    PagesRoutingModule,
    MatTooltipModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    MatTreeModule,
    MatExpansionModule,
    MatDialogModule,
    MatMenuModule,
    MatSelectModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class PagesModule { }
