import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { MenuDialogComponent } from '../menu-dialog/menu-dialog.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  constructor(private router: Router, public dialog: MatDialog){

}
 
  openMenuDialog(){
    this.dialog.open(MenuDialogComponent,{
      panelClass: 'fullscreen-dialog',
      height: '100vh',
      width: '100%'
    })
  }
}
