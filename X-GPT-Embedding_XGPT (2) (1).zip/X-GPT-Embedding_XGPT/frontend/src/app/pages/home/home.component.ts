import { AfterViewChecked, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { concatMap, of, tap } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { CommonService } from 'src/app/services/common/common.service';
import { VoiceRecognitionService } from 'src/app/services/common/voice-recognition.service';
import { apiList } from 'src/app/services/https/api-list';
import { HttpsService } from 'src/app/services/https/https.service';
import * as uniqid from 'uniqid';
import { VirtualKeyboardComponent } from '../prompt/virtual-keyboard/virtual-keyboard.component';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewChecked {
  id: any;
  isSearch!: boolean;
  suggestions: any[] = [];
  search!: string;
  searched!: string;
  prompt: string = "default";
  result: any = {};
  sessionId: any = '';
  chatSessionId = uniqid();
  darkMode: boolean = false;
  answerArray: any[] = []
  @ViewChild('chatContainer')
  private chatContainer!: ElementRef;
  public isUserSpeaking: boolean = false;
  avatarImagePath = ""
  currentYear: any = new Date().getFullYear();
  constructor(
    private https: HttpsService,
    private apilist: apiList,
    private common: CommonService,
    private router: Router,
    private voiceRecognition: VoiceRecognitionService,
    private dialog: MatDialog) {
    if (localStorage.getItem("sessionId")) {
      this.sessionId = localStorage.getItem("sessionId");
    }
    if (localStorage.getItem("userId")) {
      this.id = localStorage.getItem("userId");
      this.getSuggestions();
    } else {
      localStorage.clear();
      this.router.navigateByUrl("/login")
    }
    this.common.newSearch.subscribe((res: any) => {
      if (res) {
        this.prompt = "default";
        this.search = res.recentSearch;
        this.getResult();
      }
    })
    this.common.isDarkMode.subscribe((res: boolean) => {
      this.darkMode = res;
    })
    this.common.newGptAvatar.subscribe((response: string) => {
      this.avatarImagePath = response
    })
    console.log("avatarImagePath::>>", this.avatarImagePath)
  }
  ngOnInit() {
    this.scrollToBottom();
    this.initVoiceInput();

  }
  ngAfterViewChecked() {
    this.scrollToBottom();
  }
  getSuggestions() {
    this.https.httpGetWithHeader(this.apilist.suggestions, '').subscribe((res: any) => {
      if (res) {
        this.suggestions = ['Flight Details', ...res];
      }
    });
  }

  getResult() {
    if (this.search) {
      this.stopRecording();
      const search = this.search;
      const url = `${this.apilist.search}${this.prompt}&message=${search}`;

      this.https.httpGetWithHeader(url, '').pipe(
        tap((res: any) => {
          this.isSearch = true;
          this.searched = JSON.parse(JSON.stringify(search));
          this.result = res;
        }),
        concatMap(() => {
          const url = `${this.apilist.saveRecentSearch}${this.id}&message=${search}&sessionId=${this.sessionId}&answer=${this.result?.result}&chatSessionId=${this.chatSessionId}`;
          return this.https.httpPostWithHeader(url, '');
        }),
        concatMap((res: any) => {
          if (res.message) {
            const url = `${this.apilist.getChatHistory}${this.id}&sessionId=${this.sessionId}&chatSessionId=${this.chatSessionId}`;
            return this.https.httpGetWithHeader(url, '');
          } else {
            return of(null);
          }
        })
      ).subscribe(
        (res: any) => {
          if (res) {

            this.answerArray = res.reverse();
            this.search = ""
          }
          this.common.updateSearch.next(true);
        },
        (error: any) => {
          if (error.status === 200) {
            console.log(error.error);
            this.common.updateSearch.next(true);
          }
        }
      );
    }
  }



  // getResult() {
  //   if (this.search) {
  //     const url = `${this.apilist.search}${this.prompt}&message=${this.search}`
  //     this.https.httpGetWithHeader(url, '').subscribe((res: any) => {
  //       this.isSearch = true;
  //       this.searched = JSON.parse(JSON.stringify(this.search));
  //       this.result = res.result;
  //       this.saveSearchHistory();
  //     });
  //   }

  // }

  // saveSearchHistory() {
  //   const url = `${this.apilist.saveRecentSearch}${this.id}&message=${this.search}&sessionId=${this.sessionId}&answer=${this.result}&chatSessionId=${this.chatSessionId}`
  //   this.https.httpPostWithHeader(url, '').subscribe((res: any) => {
  //    console.log("abcd::>>",res )

  //     if (res.message) {

  //       this.getChatHistory(this.chatSessionId)
  //     }

  //   }, (error: any) => {
  //     if (error.status === 200) {
  //  console.log(error.error)
  //       this.common.updateSearch.next(true);
  //     }
  //   });
  // };

  // getChatHistory(chatSessionId: any) {
  //   debugger;
  //   const url = `${this.apilist.getChatHistory}${this.id}&sessionId=${this.sessionId}&chatSessionId=${chatSessionId}`
  //   this.https.httpGetWithHeader(url, '').subscribe((res: any) => {

  //     this.answerArray = res;
  //     this.common.updateSearch.next(true);
  //   }, (error: any) => {
  //     if (error.status === 200) {
  //       // this.result = error.error.text;
  //       this.common.updateSearch.next(true);
  //     }
  //   });
  // }
  
  enter(event: any) {
    if (event && event.keyCode && event.keyCode === 13) {
      this.getResult();

    }
  }

  refresh() {
    this.chatSessionId = uniqid();
    this.isSearch = false;
    this.prompt = "default";
    this.result = "";
    this.answerArray = [];
    this.search = "";
    this.searched = "";
  }


  scrollToBottom(): void {
    try {
      this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
    } catch (err) { }
  }

  /**
  * @description Function to stop recording.
  */
  stopRecording() {
    this.voiceRecognition.stop();
    this.isUserSpeaking = false;
  }
  /**
 * @description Function for initializing voice input so user can chat with machine.
 */
  initVoiceInput() {
    // Subscription for initializing and this will call when user stopped speaking.
    this.voiceRecognition.init()
  }
  /**
   * @description Function to enable voice input.
   */
  startRecording() {
    this.isUserSpeaking = true;
    this.voiceRecognition.start();
    this.search = '';
    // Subscription to detect user input from voice to text.
    this.voiceRecognition.speechInput().subscribe((input) => {
      // Set voice text output to
      this.search = input
    });
  }

  showKeyboard() {
    const dialogRef = this.dialog.open(VirtualKeyboardComponent, {
      width: '850px',

      height: '450px'
    })

    dialogRef.afterClosed().subscribe((data) => {
      this.search = data.textValue;
      this.getResult()
    });
  }

}
