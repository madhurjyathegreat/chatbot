import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { avatarsArray } from 'src/app/constant';
// import { FileSaver } from 'file-saver';
@Component({
  selector: 'app-avatar-dialog',
  templateUrl: './avatar-dialog.component.html',
  styleUrls: ['./avatar-dialog.component.scss']
})
export class AvatarDialogComponent {
  avtarArray = avatarsArray
  image: string | ArrayBuffer | null | undefined;
  constructor(public dialogRef: MatDialogRef<AvatarDialogComponent>){ }

  onClickAvatar(imagePath:string){
    const reader = new FileReader();
   
    if (document && document.querySelector(".imageClass")) {
      const imageHTML = <HTMLImageElement>(document.querySelector(".imageClass"));
      const imageBlob = new Blob([imageHTML.src], { type: 'image/png' });
      reader.readAsDataURL(imageBlob);
    }
    reader.onload = (event) => {
      if (event.target) {
        this.image = event.target.result;
      }
      console.log("this.image::>>", this.image)
    };
    this.dialogRef.close({
      path: imagePath,
    });
  }
}
