import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common/common.service';
import { apiList } from 'src/app/services/https/api-list';
import { HttpsService } from 'src/app/services/https/https.service';
import { AvatarDialogComponent } from './avatar-dialog/avatar-dialog.component';

@Component({
  selector: 'app-avatar-box',
  templateUrl: './avatar-box.component.html',
  styleUrls: ['./avatar-box.component.scss']
})
export class AvatarBoxComponent {
  avatarImagePath = "";
  id: any;
  darkMode: boolean = false;
  userDetail = JSON.parse(localStorage.getItem("userDetail")||'');
  constructor(private https: HttpsService,
    private apilist: apiList,
    private common: CommonService,
    private router: Router,
    private dialog: MatDialog){
    if (localStorage.getItem("userId")) {
      this.id = localStorage.getItem("userId");
    }
    this.common.newGptAvatar.subscribe((response: string) => {
      this.avatarImagePath = response
    })
   
  }
  logout() {
    localStorage.clear();
    this.router.navigateByUrl("/login");
  }
  changeMode() {
    this.darkMode = !this.darkMode;
    this.common.darkMode.next(this.darkMode);
  }

  showAvatar() {
    const avatarDialogRef = this.dialog.open(AvatarDialogComponent, {
      width: ' 450px',
    })
    avatarDialogRef.afterClosed().subscribe((data) => {
      console.log("data.path::>>", data.path)
      // this.avatarImagePath = data.path;
      this.common.getGptAvatar.next(data.path)
    });
  }
}
