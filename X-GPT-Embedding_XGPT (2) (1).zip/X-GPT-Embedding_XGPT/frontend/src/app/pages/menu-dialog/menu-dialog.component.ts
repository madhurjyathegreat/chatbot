import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common/common.service';

@Component({
  selector: 'app-menu-dialog',
  templateUrl: './menu-dialog.component.html',
  styleUrls: ['./menu-dialog.component.scss']
})
export class MenuDialogComponent {
  constructor(public dialogRef: MatDialogRef<MenuDialogComponent>, private router: Router,private common: CommonService){

 }

 onClose(){
  this.dialogRef.close()
 }
  logout() {
    localStorage.clear();
    this.router.navigateByUrl("/login");
    this.common.searchData.next(null);
    this.onClose()
  }
  goToHistory() {
    this.router.navigateByUrl('/history');
    this.onClose()
  }
}
