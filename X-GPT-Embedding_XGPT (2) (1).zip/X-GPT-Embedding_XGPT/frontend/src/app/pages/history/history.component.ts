import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common/common.service';
import { apiList } from 'src/app/services/https/api-list';
import { HttpsService } from 'src/app/services/https/https.service';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent {
  panelOpenState = true;
  id: any;
  sessionId: any = '';
  result: any[] = [];
  sessions: any[] = [];
  darkMode: boolean = false;
  sessions2: any = {};
  userName = localStorage.getItem("userName");
  constructor(private https: HttpsService,
    private apilist: apiList,
    private common: CommonService,
    private router: Router,) {
    if (localStorage.getItem("userId")) {
      this.id = localStorage.getItem("userId");
    }
    if (localStorage.getItem("sessionId")) {
      this.sessionId = localStorage.getItem("sessionId");
    }
    //this.getRecentHistory();
    this.getSessionId();
    this.common.isSearchChange.subscribe((res: any) => {
      if (res) {
        if (localStorage.getItem("userId")) {
          this.id = localStorage.getItem("userId");
        }
        if (localStorage.getItem("sessionId")) {
          this.sessionId = localStorage.getItem("sessionId");
        }
        // !this.checkSession() && this.getSessionId();
        this.getSessionId();
        // this.getRecentHistory();
      }


    })

    
  }
  getSessionId() {
    this.https.httpGetWithHeader(this.apilist.getSessionId + this.id, '').subscribe((res: any) => {
      if (res) {
        let response: any[] = [];
        response = res;
        this.sessions = response.reverse();
        this.sessions = this.sessions.map((item: any) => {
          const newItem = { ...item }
          this.getRecentHistory2(newItem.sessionId).subscribe((res: any) => {
            if (res) {
              newItem.sessionArray = res;
            }
          });
          return newItem
        })
        console.log("this.sessions::>>>", this.sessions)
      }
    });
  }
  getRecentHistory2(sessionId: string) {
    return this.https.httpGetWithHeader(this.apilist.getRecentSearch + this.id + '&sessionId=' + sessionId, '');
  }
  goToback() {
    this.common.searchData.next(null);
    this.router.navigateByUrl('/home');

  }

  getTimeFromString(time:string){
    const date = new Date(time);

    // AM format
    const timeAM = date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    });
    return timeAM
  }
  searchAgain(item: any) {
    this.common.searchData.next(item);
    this.router.navigateByUrl('/home')
  }
}
