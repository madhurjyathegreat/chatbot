import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PagesComponent } from './pages.component';
import { PromptComponent } from './prompt/prompt.component';
import { HistoryComponent } from './history/history.component';

const routes: Routes = [{
  path: '',
  component: PagesComponent,
  children: [
    // { path: 'home', component: HomeComponent },
    { path: 'home', component: PromptComponent },
    { path: 'history', component: HistoryComponent },
    { path: 'home', redirectTo: 'prompt' }
  ]
}

 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
